<?php

add_action( 'init', 'JAMSESSION_SWP_create_photo_albums_post' );
function JAMSESSION_SWP_create_photo_albums_post() 
{
	$slug = JAMSESSION_SWP_JPT_get_plugin_option("photo_album");
	
	if ( "" == $slug)
	{
		$slug = "js_photo_albums";
	}
	
	register_post_type( 'js_photo_albums',
		array(
			'labels' => array(
				'name' =>  __('Photo Albums', 'jamsession') ,
				'singular_name' =>  __('Photo Album', 'jamsession') ,
				'add_new' => __('Add New Photo Album', 'jamsession'),
				'add_new_item' => __('Add New Photo Album', 'jamsession'),
				'edit' => __('Edit', 'jamsession'),
				'edit_item' => __('Edit Photo Album', 'jamsession'),
				'new_item' => __('New Photo Album', 'jamsession'),
				'view' => __('View', 'jamsession'),
				'view_item' => __('View Photo Album', 'jamsession'),
				'search_items' => __('Search Photo Albums', 'jamsession'),
				'not_found' => __('No Photo Albums found','jamsession'),
				'not_found_in_trash' => __('No Photo Albums Found in Trash','jamsession'),
				'parent' => __('Parent Photo Album','jamsession')
			),
		'public' => true,
		'rewrite' => array(
			'slug' => $slug,
			'with_front' => false
			),			
		'supports' => array( 'title', 'editor', 'comments', 'thumbnail'),
		'menu_icon' => 'dashicons-camera'
		)
	); 
}


/*
	admin section - add meta box to edit post
*/
add_action( 'admin_init', 'JAMSESSION_SWP_photo_albums_admin_init' );
function JAMSESSION_SWP_photo_albums_admin_init() 
{
    add_meta_box( 'photo_albums_meta_box', 	/*the required HTML id attribute*/
        __('Image Gallery','jamsession'), 	/*text visible in the heading of meta box section*/
        'JAMSESSION_SWP_display_photo_albums_meta_box',	/* callback FUNCTION which renders the contents of the meta box*/
        'js_photo_albums', 					/*the name of the custom post type where the meta box will be displayed*/
		'normal', 							/*defines the part of the page where the edit screen section should be shown*/
		'high' 								/*defines the priority within the context where the boxes should show*/
    );
}




/*
	callback FUNCTION which renders the contents of the meta box
	$photoAlbumObject
*/
function JAMSESSION_SWP_display_photo_albums_meta_box( $photoAlbumObject ) 
{
	/* display media attacched to post */
	echo JAMSESSION_SWP_display_gallery($photoAlbumObject->ID);
	
	/* display upload media form */
	global $post;
			
	wp_enqueue_script('plupload-handlers');
			
	$form_class='media-upload-form type-form validate';
	$post_id = $post->ID;
	$_REQUEST['post_id'] = $post_id;

	media_upload_form(); 
	
	$media_params = array( 
						'post_id' => $post_id,
						'short_form' => '3');
	
	?>	
 	<div id="media-items" class="hide-if-no-js"></div>
	 <?php	
	wp_localize_script( 
						'media_upload_assets', 
						'JAMSESSION_SWP_scriptParams',
						$media_params ); 
						
}

/*
		display gallery html code at the top of the custom metabox
*/
function JAMSESSION_SWP_display_gallery($photo_album_ID)
{
	$args = array(
		'post_type'         => 'attachment',
		'post_status'       => 'inherit',
		'post_parent'       => $photo_album_ID,
		'post_mime_type'    => 'image',
		'posts_per_page'    => -1,
		'order'             => 'ASC',
		'orderby'           => 'menu_order',
		);

	$loop = get_posts( $args );
		

	if( empty( $loop ) )
	{
		return "";
	}

	$gallery = '<div id="js_gallery_admin">';
	$ii = 0;
	foreach( $loop as $image ):
	
		/*get the thumbnail*/
		$thumbnail	= wp_get_attachment_image_src( $image->ID, 'medium');
		
		/*put it in html*/
		$gallery .= '<div class="image_cell">';
		$gallery .= '<img src="' . $thumbnail[0] . '"  alt="' . $image->post_title . '" rel="' . $image->ID . '" title="' . $image->post_content . '" /> ';
		
		// delete and edit links 		
		$gallery .= '<div class="image_action"><span class="remove_image" rel="' . $image->ID .'">Remove</span></div>';
		//$gallery .= '<div class="image_action"> <a href="'.get_edit_post_link($image->ID).'&width=800&height=550" class="thickbox" style="text-decoration: none;">Edit</a></div>';
		$gallery .= '<div class="image_action"> <a href="'.get_edit_post_link($image->ID).'" target="_blank">Edit</a></div>';
		$gallery .= '</div>';

	endforeach;

	$gallery .= '</div>';

	return $gallery;	
}



add_action( 'wp_ajax_JAMSESSION_SWP_remove_from_gallery', 'JAMSESSION_SWP_remove_from_gallery');
add_action( 'wp_ajax_JAMSESSION_SWP_update_my_gallery', 'JAMSESSION_SWP_update_my_gallery');

/*
	update gallery in html code - called from js
*/

function JAMSESSION_SWP_update_my_gallery()
{
	$parent	= $_POST['parent'];
	
	
	$images = JAMSESSION_SWP_display_gallery($parent);
	
	$ret['success'] = true;
	$ret['gallery'] = $images;
	
	echo json_encode( $ret );
	die();
}

/*
	remove picture item from gallery - called from js
*/

function JAMSESSION_SWP_remove_from_gallery() 
{
		/*	 get content from AJAX post */
		$image = $_POST['image'];
		$parent	= $_POST['parent'];

		/* no image ID .. this is strange */
		if( empty( $image ) ) 
		{
			$ret['success'] = false;
			echo json_encode( $ret );
			die();
		}

		/* setup removal function*/
		$remove                 = array();
		$remove['ID']           = $image;
		$remove['post_parent']	= 0;

		$update = wp_update_post( $remove );

		// AJAX return array
		$ret = array();

		if( $update !== 0 ) 
		{
			/* refresh the gallery */
			$images = JAMSESSION_SWP_display_gallery( $parent);
			
			/* return values */
			$ret['success'] = true;
			$ret['gallery'] = $images;

		} 
		else 
		{
			/* return fails */
			$ret['success'] = false;
		}

		echo json_encode( $ret );
		die();
}


/*
	adding custom columns to admin menu using filter  [manage_edit-{post_type}_columns]
*/
add_filter('manage_edit-js_photo_albums_columns', 'JAMSESSION_SWP_js_photo_albums_admin_columns_func');

function JAMSESSION_SWP_js_photo_albums_admin_columns_func( $columns)
{
	$columns = array(
		'title' => __('Photo Album Title', 'jamsession'),
		'author'	=> __('Author', 'jamsession'),
		'date'		=> __('Date', 'jamsession')		
		
	);
	
	return $columns;
}

/* 
	making custom comumns sortable
*/
add_filter( 'manage_edit-js_photo_albums_sortable_columns', 'JAMSESSION_SWP_js_photo_albums_sortable_columns' );

function JAMSESSION_SWP_js_photo_albums_sortable_columns( $columns ) 
{

	$columns['author'] = 'author';

	return $columns;
}



/*
	Create Category for Photo Albums
*/
add_action( 'init', 'JAMSESSION_SWP_create_photo_album_category', 0 );

function JAMSESSION_SWP_create_photo_album_category()
{
	register_taxonomy(
			'photo_album_category',
			'js_photo_albums',
			array(
				'labels' => array(
					'name' => __('Photo Album Categories', 'jamsession'),
					'singular_name'     => __( 'Photo Album Category', 'jamsession' ),
					'search_items'      => __( 'Search Photo Album Categories', 'jamsession'  ),
					'all_items'         => __( 'All Photo Album Categories', 'jamsession'  ),
					'parent_item'       => __( 'Parent Photo Album Category', 'jamsession'  ),
					'parent_item_colon' => __( 'Parent Photo Album Category:', 'jamsession'  ),
					'edit_item'         => __( 'Edit Photo Album Category' , 'jamsession' ),
					'update_item'       => __( 'Update Photo Album Category', 'jamsession'  ),
					'add_new_item' 		=> __('Add New Photo Album Category', 'jamsession'),
					'new_item_name' 	=> __('New Photo Album Category', 'jamsession'),
				),
				'show_ui' => true,
				'show_tagcloud' => false,
				'hierarchical' => true
			)
		);
}

?>