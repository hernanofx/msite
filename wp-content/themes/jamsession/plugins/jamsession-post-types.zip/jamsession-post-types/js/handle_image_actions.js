/*
	image removal function - fired at load and after AJAX
*/
		
	function removeImage() {

		jQuery('span.remove_image').on('click', function(event) 
		{
			
			var image	= jQuery(this).attr('rel');
			var parent	= jQuery('form#post input#post_ID').prop('value');
			
			
			
			var data = {
				action: 'JAMSESSION_SWP_remove_from_gallery',
				image: image,
				parent: parent
			};

			
			jQuery.post(ajaxurl, data, function(response) 
			{
				var obj;
				
				//alert("response);

				try 
				{
					obj = jQuery.parseJSON(response);
					
				}
				catch(e) 
				{ 
				
					/*catch some error*/
				}

				if(obj.success === true) 
				{ 
					/*things OK*/
					
					jQuery('div#js_gallery_admin').replaceWith(obj.gallery);
					removeImage();
				}
				else 
				{
				
				/*problems..*/
				}
			});

		});

	}
	
	function update_gallery()
	{
		var parent	= jQuery('form#post input#post_ID').prop('value');
		var data = {
		action: 'JAMSESSION_SWP_update_my_gallery',
		parent: parent
		};
				
		jQuery.post(ajaxurl, data, function(response) 
		{
			var obj;
				
			try 
			{
				obj = jQuery.parseJSON(response);
			}
			catch(e) 
			{ 
				/*catch some error*/
			}

			if(obj.success === true) 
			{ 
				/*things OK*/
				jQuery('div#js_gallery_admin').replaceWith(obj.gallery);
				removeImage();
			}
			else 
			{
				/*problems..*/
			}
		});				
	}
	
	
	/*
		detect media changes on gallery post - trigger for update_gallery()
	*/
	function detectMediaChanges() 
	{
		jQuery('#media-items').bind("DOMSubtreeModified", function() {
			  update_gallery();
			});
	}

	
	
/*
	starting...
*/
jQuery(document).ready( function($) {

	/* call the image removal function on loading*/
	removeImage();
	detectMediaChanges();
});