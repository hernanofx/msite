'use strict';
if (typeof JAMSESSION_SWP_scriptParams !== "undefined") {
	var post_id = JAMSESSION_SWP_scriptParams.post_id;
	var shortform = JAMSESSION_SWP_scriptParams.short_form;
}