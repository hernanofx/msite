<?php
require_once vc_path_dir( 'SHORTCODES_DIR', 'vc-column.php' );
Class WPBakeryShortCode_VC_Gitem_Zone extends WPBakeryShortCodesContainer {
	public $zone_name = '';
}